# AmericanMovieCrypto
American Movie Crypto is a decentralized movie streaming platform on the Binance Smart Chain (BSC) that will allow users to watch American Classic Movies and amateur produced films from around the world using our classic token ($AMC) as the primary medium of exchange.
